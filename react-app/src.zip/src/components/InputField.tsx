import React from 'react';

interface InputFieldProps {
  value: string;
  onChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  error: boolean;
  placeholder: string;
}

const InputField: React.FC<InputFieldProps> = ({ value, onChange, error, placeholder }) => {
  return (
    <div>
      <label >Enter a number</label>
      <br />
      <input
        type="text"
        value={value}
        onChange={onChange}
        placeholder={placeholder}
      />
    </div>
  );
};

export default InputField;
