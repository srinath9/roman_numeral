export const lightTheme = {
    background: '#ffffff',
    color: '#000000',
  };
  
  export const darkTheme = {
    background: '#333333',
    color: '#ffffff',
  };
  
  
  export type ThemeType = typeof lightTheme; 